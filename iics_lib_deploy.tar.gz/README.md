# IICS_lib

一个基于 Flask、SQLite 和 Waitress 的论文库。网页只允许白名单账号访问；每个账号首次使用时自行创建密码。登录 Cookie 保留 30 天。论文 PDF 保存在文件夹中，论文信息和自动生成的 Terms 存在 SQLite 数据库中。

## Windows 本机运行

双击 `IICS_lib 后台.lnk`，或运行 `启动IICS_lib后台.bat`。第一次启动会在 `.venv` 中安装依赖。网站会打开在 <http://127.0.0.1:8787>。初始管理员用户名是 `admin`，第一次登录时创建密码；进入“管理”可以添加白名单账号、调整权限、停用或移除账号，以及重置密码。

## Linux 服务器运行

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
export IICS_ADMIN_USERNAME=admin
export IICS_HOST=127.0.0.1
export IICS_PORT=8787
export IICS_COOKIE_SECURE=1
waitress-serve --listen=127.0.0.1:8787 app:app
```

首次运行会建立 `instance/iics_lib.sqlite3` 和 `instance/secret.key`，并扫描项目目录下的 PDF。请通过 HTTPS 反向代理发布服务，保持应用仅监听回环地址，并将 `IICS_COOKIE_SECURE=1` 用于 HTTPS。上线后备份 `instance/` 和 `uploads/`；`secret.key` 更换后现有登录 Cookie 会失效。设置管理员用户名时使用服务进程的 `IICS_ADMIN_USERNAME` 环境变量，且在首次运行数据库前设置。

首次设密按当前流程仅凭白名单用户名识别用户。对公网开放前，应增加一次性邀请码、机构邮箱或 SSO 验证，避免他人抢先创建白名单账号密码。

## 功能

- 白名单用户名校验、首次创建密码、密码哈希存储、持久登录 Cookie。
- 管理员维护白名单和权限、停用或移除账号、重置密码。
- 按分类、期刊或会议、年份、Terms 过滤；搜索题名和 PDF 前两页文字。
- 上传 PDF 并自动生成 Terms 索引，登录后下载。
- 原始论文继续按 `分类/期刊或会议/年份/文件名.pdf` 组织；网站上传的文件放在 `uploads/`。
