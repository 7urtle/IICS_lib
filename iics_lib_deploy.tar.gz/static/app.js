(() => {
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const state = { user: null, csrf: "", papers: [], facets: null, filters: { q: "", category: "", venue: "", year: "", term: "" }, toastTimer: null };
  const esc = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);

  async function api(url, options = {}) {
    const headers = new Headers(options.headers || {});
    if (state.csrf) headers.set("X-CSRF-Token", state.csrf);
    if (options.body && !(options.body instanceof FormData)) headers.set("Content-Type", "application/json");
    const response = await fetch(url, { ...options, headers, credentials: "same-origin" });
    const type = response.headers.get("content-type") || "";
    const data = type.includes("application/json") ? await response.json() : null;
    if (response.status === 401 && url !== "/api/auth/password") {
      state.user = null;
      state.csrf = "";
      showLogin();
    }
    if (!response.ok) throw new Error(data?.error || `请求失败 (${response.status})`);
    return data;
  }

  function showLogin() {
    $("#login-screen").hidden = false;
    $("#app-shell").hidden = true;
    $("#identify-form").hidden = false;
    $("#password-form").hidden = true;
    $("#login-error").textContent = "";
    $("#password-error").textContent = "";
    $("#username").value = "";
    $("#username").focus();
  }

  function showApp() {
    $("#login-screen").hidden = true;
    $("#app-shell").hidden = false;
    $("#current-username").textContent = state.user.username;
    $("#user-avatar").textContent = state.user.username.slice(0, 1).toUpperCase();
    $$(".admin-only").forEach((button) => { button.hidden = state.user.role !== "admin"; });
    loadPapers().catch((error) => toast(error.message));
  }

  async function bootstrap() {
    try {
      const session = await api("/api/session");
      if (session.user) {
        state.user = session.user;
        state.csrf = session.csrf;
        showApp();
      } else showLogin();
    } catch { showLogin(); }
  }

  $("#identify-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const button = $("#identify-form button[type=submit]");
    button.disabled = true;
    $("#login-error").textContent = "";
    try {
      const data = await fetch("/api/auth/identify", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username: $("#username").value.trim() }) }).then(async (response) => {
        const body = await response.json();
        if (!response.ok) throw new Error(body.error);
        return body;
      });
      $("#identified-user").textContent = data.username;
      $("#password-label").textContent = data.first_login ? "创建密码" : "密码";
      $("#password").autocomplete = data.first_login ? "new-password" : "current-password";
      $("#confirm-wrap").hidden = !data.first_login;
      $("#confirm-password").hidden = !data.first_login;
      $("#password").value = "";
      $("#confirm-password").value = "";
      $("#password-submit").innerHTML = `${data.first_login ? "创建并登录" : "登录"} <span aria-hidden="true">→</span>`;
      $("#identify-form").hidden = true;
      $("#password-form").hidden = false;
      $("#password").focus();
    } catch (error) { $("#login-error").textContent = error.message; }
    finally { button.disabled = false; }
  });

  $("#back-to-username").addEventListener("click", () => {
    $("#password-form").hidden = true;
    $("#identify-form").hidden = false;
    $("#username").focus();
  });

  $("#password-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const button = $("#password-submit");
    button.disabled = true;
    $("#password-error").textContent = "";
    try {
      const password = $("#password").value;
      const creating = !$("#confirm-wrap").hidden;
      if (creating && password !== $("#confirm-password").value) throw new Error("两次输入的密码不一致");
      const result = await api("/api/auth/password", { method: "POST", body: JSON.stringify({ username: $("#identified-user").textContent, password }) });
      state.user = result.user;
      state.csrf = result.csrf;
      showApp();
    } catch (error) { $("#password-error").textContent = error.message; }
    finally { button.disabled = false; }
  });

  function fillSelect(select, values, label) {
    const previous = select.value;
    select.replaceChildren(new Option(label, ""), ...values.map((value) => new Option(value, value)));
    if (values.includes(previous)) select.value = previous;
  }

  async function loadPapers() {
    const params = new URLSearchParams(Object.entries(state.filters).filter(([, value]) => value));
    const data = await api(`/api/papers?${params}`);
    state.papers = data.papers;
    state.facets = data.facets;
    fillSelect($("#filter-category"), data.facets.categories, "全部分类");
    fillSelect($("#filter-venue"), data.facets.venues, "全部刊会");
    fillSelect($("#filter-year"), data.facets.years, "全部年份");
    $("#paper-total").textContent = data.total.toLocaleString();
    $("#stat-papers").textContent = data.total.toLocaleString();
    $("#stat-venues").textContent = data.facets.venues.length.toLocaleString();
    $("#stat-terms").textContent = data.facets.terms.length.toLocaleString();
    $("#stat-years").textContent = data.facets.years.length ? `${Math.min(...data.facets.years.map(Number).filter(Number.isFinite)) || data.facets.years.at(-1)}—${data.facets.years[0]}` : "—";
    $("#match-count").textContent = `${data.matches.toLocaleString()} 篇结果`;
    $("#active-term").hidden = !state.filters.term;
    $("#active-term").innerHTML = state.filters.term ? `${esc(state.filters.term)} <button type="button" aria-label="清除 term 筛选">×</button>` : "";
    if (state.filters.term) $("#active-term button").addEventListener("click", () => { state.filters.term = ""; loadPapers(); });
    renderPapers(data.papers);
    renderTerms(data.facets.terms);
  }

  function renderPapers(papers) {
    const tbody = $("#paper-rows");
    tbody.innerHTML = papers.map((paper) => `
      <tr>
        <td><div class="paper-title"><span class="paper-type">PDF</span><div class="paper-title-main"><strong>${esc(paper.title)}</strong><small>${esc(paper.category)}${paper.is_upload ? " · 已上传" : ""}</small></div></div></td>
        <td><span class="venue-text">${esc(paper.venue)}</span></td>
        <td><span class="year-text">${esc(paper.year)}</span></td>
        <td><div class="paper-terms">${paper.terms.slice(0, 5).map((term) => `<button type="button" class="term-chip" data-term="${esc(term)}" title="筛选 ${esc(term)}">${esc(term)}</button>`).join("")}</div></td>
        <td><a class="download-link" href="/api/papers/${paper.id}/download" title="下载论文" aria-label="下载 ${esc(paper.title)}">↓</a>${state.user.role === "admin" && paper.is_upload ? `<button class="download-link delete-paper" type="button" data-id="${paper.id}" title="删除上传论文" aria-label="删除 ${esc(paper.title)}">×</button>` : ""}</td>
      </tr>`).join("");
    $("#empty-state").hidden = papers.length !== 0;
    $$(".term-chip", tbody).forEach((button) => button.addEventListener("click", () => { state.filters.term = button.dataset.term; activateView("library"); loadPapers(); }));
    $$(".delete-paper", tbody).forEach((button) => button.addEventListener("click", async () => {
      if (!confirm("删除这篇已上传的论文？")) return;
      try { await api(`/api/papers/${button.dataset.id}`, { method: "DELETE" }); toast("论文已删除"); await loadPapers(); }
      catch (error) { toast(error.message); }
    }));
  }

  function renderTerms(terms) {
    $("#terms-total").textContent = terms.length.toLocaleString();
    const query = $("#term-search-input").value.trim().toLowerCase();
    const visible = terms.filter((item) => item.name.toLowerCase().includes(query));
    $("#term-grid").innerHTML = visible.map((item) => `<button type="button" class="term-tile" data-term="${esc(item.name)}"><strong>${esc(item.name)}</strong><span>${item.count}</span></button>`).join("");
    $$(".term-tile").forEach((button) => button.addEventListener("click", () => {
      state.filters.term = button.dataset.term;
      $("#filter-category").value = ""; $("#filter-venue").value = ""; $("#filter-year").value = "";
      state.filters.category = ""; state.filters.venue = ""; state.filters.year = "";
      activateView("library"); loadPapers();
    }));
  }

  function activateView(name) {
    if (name === "admin" && state.user.role !== "admin") return;
    $$(".nav-button").forEach((button) => button.classList.toggle("active", button.dataset.view === name));
    $$(".view").forEach((view) => {
      const active = view.id === `${name}-view`;
      view.classList.toggle("active-view", active);
      view.hidden = !active;
    });
    if (name === "admin") loadUsers().catch((error) => toast(error.message));
    if (name === "terms" && state.facets) renderTerms(state.facets.terms);
    if (name === "library") loadPapers().catch((error) => toast(error.message));
  }

  async function loadUsers() {
    const data = await api("/api/users");
    $("#user-count").textContent = `${data.users.length} 个账号`;
    $("#user-rows").innerHTML = data.users.map((user) => `
      <tr>
        <td>${esc(user.username)}${user.id === Number(state.user.id) ? " <span class=\"muted\">(我)</span>" : ""}</td>
        <td><select class="role-select" data-role-id="${user.id}" aria-label="${esc(user.username)} 的权限"><option value="member" ${user.role === "member" ? "selected" : ""}>成员</option><option value="admin" ${user.role === "admin" ? "selected" : ""}>管理员</option></select></td>
        <td>${user.has_password ? "已设置" : "待首次登录"}</td>
        <td><span class="state-label ${user.active ? "" : "off"}">${user.active ? "启用" : "停用"}</span></td>
        <td>${esc(user.created_at.slice(0, 10))}</td>
        <td><div class="user-actions"><button type="button" class="table-action reset-user" data-id="${user.id}" data-name="${esc(user.username)}">重置密码</button><button type="button" class="table-action toggle-user" data-id="${user.id}" data-active="${user.active}" ${user.id === Number(state.user.id) ? "disabled" : ""}>${user.active ? "停用" : "启用"}</button><button type="button" class="table-action danger remove-user" data-id="${user.id}" data-name="${esc(user.username)}" ${user.id === Number(state.user.id) ? "disabled" : ""}>移除</button></div></td>
      </tr>`).join("");
    $$(".role-select").forEach((select) => select.addEventListener("change", async () => {
      try { await api(`/api/users/${select.dataset.roleId}`, { method: "PATCH", body: JSON.stringify({ role: select.value }) }); toast("权限已更新"); await loadUsers(); }
      catch (error) { toast(error.message); await loadUsers(); }
    }));
    $$(".reset-user").forEach((button) => button.addEventListener("click", async () => {
      if (!confirm(`重置 ${button.dataset.name} 的密码？对方下次登录时需要重新创建密码。`)) return;
      try { await api(`/api/users/${button.dataset.id}`, { method: "PATCH", body: JSON.stringify({ reset_password: true }) }); toast("密码已重置"); await loadUsers(); }
      catch (error) { toast(error.message); }
    }));
    $$(".toggle-user").forEach((button) => button.addEventListener("click", async () => {
      try { await api(`/api/users/${button.dataset.id}`, { method: "PATCH", body: JSON.stringify({ active: button.dataset.active !== "true" }) }); toast("账号状态已更新"); await loadUsers(); }
      catch (error) { toast(error.message); }
    }));
    $$(".remove-user").forEach((button) => button.addEventListener("click", async () => {
      if (!confirm(`从白名单移除 ${button.dataset.name}？`)) return;
      try { await api(`/api/users/${button.dataset.id}`, { method: "DELETE" }); toast("账号已移除"); await loadUsers(); }
      catch (error) { toast(error.message); }
    }));
  }

  function toast(message) {
    const element = $("#toast");
    element.textContent = message;
    element.classList.add("show");
    clearTimeout(state.toastTimer);
    state.toastTimer = setTimeout(() => element.classList.remove("show"), 2600);
  }

  $(".main-nav").addEventListener("click", (event) => {
    const button = event.target.closest("[data-view]");
    if (button) activateView(button.dataset.view);
  });
  $("#search-input").addEventListener("input", (event) => {
    state.filters.q = event.target.value;
    activateView("library");
  });
  $("#filter-category").addEventListener("change", (event) => { state.filters.category = event.target.value; loadPapers(); });
  $("#filter-venue").addEventListener("change", (event) => { state.filters.venue = event.target.value; loadPapers(); });
  $("#filter-year").addEventListener("change", (event) => { state.filters.year = event.target.value; loadPapers(); });
  $("#clear-filters").addEventListener("click", () => {
    state.filters = { q: "", category: "", venue: "", year: "", term: "" };
    $("#search-input").value = ""; $("#term-search-input").value = "";
    $("#filter-category").value = ""; $("#filter-venue").value = ""; $("#filter-year").value = "";
    loadPapers();
  });
  $("#term-search-input").addEventListener("input", () => state.facets && renderTerms(state.facets.terms));
  document.addEventListener("keydown", (event) => {
    if (event.key === "/" && !["INPUT", "TEXTAREA"].includes(document.activeElement.tagName)) { event.preventDefault(); $("#search-input").focus(); }
    if (event.key === "Escape") $("#user-menu").hidden = true;
  });
  $("#user-menu-button").addEventListener("click", () => {
    const menu = $("#user-menu"); menu.hidden = !menu.hidden;
    $("#user-menu-button").setAttribute("aria-expanded", String(!menu.hidden));
  });
  document.addEventListener("click", (event) => {
    if (!event.target.closest(".user-menu-wrap")) { $("#user-menu").hidden = true; $("#user-menu-button").setAttribute("aria-expanded", "false"); }
  });
  $("#logout-button").addEventListener("click", async () => {
    try { await api("/api/auth/logout", { method: "POST", body: "{}" }); } catch { /* The session may already have expired. */ }
    state.user = null; state.csrf = ""; showLogin();
  });
  $("#upload-open").addEventListener("click", () => $("#upload-dialog").showModal());
  $("#change-password-open").addEventListener("click", () => { $("#password-dialog").showModal(); $("#change-password-form").reset(); });
  $$('[data-close]').forEach((button) => button.addEventListener("click", () => $(`#${button.dataset.close}`).close()));
  $("#paper-file").addEventListener("change", (event) => {
    const file = event.target.files[0];
    $("#file-name").textContent = file ? file.name : "选择 PDF 文件";
    $("#file-size").textContent = file ? `${(file.size / 1024 / 1024).toFixed(1)} MB` : "单篇最大 100 MB";
  });
  $("#upload-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const submit = $("#upload-form button[type=submit]");
    submit.disabled = true; $("#upload-error").textContent = "";
    try {
      const result = await api("/api/papers", { method: "POST", body: new FormData(event.currentTarget) });
      $("#upload-dialog").close(); event.currentTarget.reset();
      $("#file-name").textContent = "选择 PDF 文件"; $("#file-size").textContent = "单篇最大 100 MB";
      state.filters = { q: "", category: "", venue: "", year: "", term: "" };
      $("#search-input").value = ""; activateView("library"); toast("论文已上传并加入索引");
      const row = state.papers.find((paper) => paper.id === result.id);
      if (row) toast("论文已上传并加入索引");
    } catch (error) { $("#upload-error").textContent = error.message; }
    finally { submit.disabled = false; }
  });
  $("#add-user-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const input = $("#new-username");
    try {
      await api("/api/users", { method: "POST", body: JSON.stringify({ username: input.value.trim(), role: $("#new-user-role").value }) });
      input.value = ""; toast("已加入白名单"); await loadUsers();
    } catch (error) { toast(error.message); }
  });
  $("#change-password-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    try {
      await api("/api/auth/change-password", { method: "POST", body: JSON.stringify({ current: form.get("current"), password: form.get("password") }) });
      $("#password-dialog").close(); toast("密码已更新");
    } catch (error) { $("#change-password-error").textContent = error.message; }
  });

  bootstrap();
})();
