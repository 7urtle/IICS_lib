from __future__ import annotations

import json
import logging
import os
import re
import queue
import secrets
import sqlite3
import threading
from collections import Counter
from datetime import timedelta
from functools import wraps
from pathlib import Path
from uuid import uuid4

from flask import Flask, abort, jsonify, render_template, request, send_file, session
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

from pypdf import PdfReader

logging.getLogger("pypdf._cmap").setLevel(logging.CRITICAL)

ROOT = Path(__file__).resolve().parent
INSTANCE = ROOT / "instance"
UPLOAD_ROOT = ROOT / "uploads"
DB_PATH = INSTANCE / "iics_lib.sqlite3"
MAX_PDF_BYTES = 100 * 1024 * 1024
STOP_WORDS = set("a an and are as at be been being by can could did do does for from had has have he her here hers him his how i if in into is it its may me more most must my no not of on one or our ours out over she should so some such than that the their theirs them then there these they this those through to too under up us very was we were what when where which while who why will with would you your about after also any each few other only using based paper approach proposed method results study new novel efficient high performance design data system first two three four following without provide presents demonstrate show analysis different existing several however because using their its which onto based computation technique technology architecture work such include presents describes".split())

app = Flask(__name__, template_folder="templates", static_folder="static")
app.config.update(
    MAX_CONTENT_LENGTH=MAX_PDF_BYTES,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("IICS_COOKIE_SECURE", "0") == "1",
    PERMANENT_SESSION_LIFETIME=timedelta(days=30),
)
INSTANCE.mkdir(exist_ok=True)
UPLOAD_ROOT.mkdir(exist_ok=True)
secret_path = INSTANCE / "secret.key"
if secret_path.exists():
    app.secret_key = secret_path.read_text(encoding="ascii").strip()
else:
    app.secret_key = secrets.token_hex(32)
    secret_path.write_text(app.secret_key, encoding="ascii")
    if os.name != "nt":
        secret_path.chmod(0o600)

db_lock = threading.Lock()
index_queue: queue.Queue[tuple[int, str]] = queue.Queue()
text_indexing_enabled = os.environ.get("IICS_TEXT_INDEXING", "1") == "1"
indexer_started = False


class ClosingConnection(sqlite3.Connection):
    def __exit__(self, exc_type, exc_value, traceback):
        try:
            return super().__exit__(exc_type, exc_value, traceback)
        finally:
            self.close()


def connect_db(path: Path | None = None) -> sqlite3.Connection:
    db = sqlite3.connect(path or DB_PATH, timeout=15, factory=ClosingConnection)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA busy_timeout=15000")
    db.execute("PRAGMA foreign_keys=ON")
    return db


def title_from_filename(filename: str) -> str:
    title = Path(filename).stem
    title = re.sub(r"^\d{5,}_", "", title)
    title = re.sub(r"[_\s]+", " ", title).strip(" ._-—")
    return title or Path(filename).stem


def infer_location(pdf_path: Path) -> tuple[str, str, str]:
    try:
        parts = pdf_path.relative_to(ROOT).parts[:-1]
    except ValueError:
        parts = ()
    if len(parts) >= 3:
        return parts[0], parts[1], parts[2]
    return "未分类", "其他", "未知"


def make_terms(title: str, text: str) -> list[str]:
    source = re.sub(r"([a-z])([A-Z])", r"\1 \2", f"{title} {text[:24000]}")
    words = re.findall(r"[A-Za-z][A-Za-z0-9.+/-]{1,}|[A-Z]{2,}[0-9]*", source)
    counts = Counter()
    for word in words:
        normalized = word.strip(".+/-").lower()
        if len(normalized) < 2 or normalized in STOP_WORDS or normalized.isdigit():
            continue
        if normalized.isalpha() and len(normalized) <= 3:
            normalized = normalized.upper()
        else:
            normalized = normalized[0].upper() + normalized[1:]
        counts[normalized] += 1
    return list(dict.fromkeys(make_title_terms(title) + [word for word, _ in counts.most_common(18)]))[:12]


def read_pdf_text(path: Path) -> str:
    try:
        reader = PdfReader(str(path), strict=False)
        return "\n".join((page.extract_text() or "") for page in reader.pages[:2])[:30000]
    except Exception:
        return ""


def make_title_terms(title: str) -> list[str]:
    source = re.sub(r"([a-z])([A-Z])", r"\1 \2", title)
    words = re.findall(r"[A-Za-z][A-Za-z0-9.+/-]{1,}|[A-Z]{2,}[0-9]*", source)
    terms = []
    for word in words:
        normalized = word.strip(".+/-").lower()
        if len(normalized) < 2 or normalized in STOP_WORDS:
            continue
        terms.append(normalized.upper() if normalized.isalpha() and len(normalized) <= 3 else normalized[0].upper() + normalized[1:])
    return list(dict.fromkeys(terms))


def insert_paper(db: sqlite3.Connection, path: Path, *, category: str | None = None,
                 venue: str | None = None, year: str | None = None, uploaded: bool = False,
                 title: str | None = None) -> None:
    relative = path.relative_to(ROOT).as_posix()
    title = title or title_from_filename(path.name)
    category0, venue0, year0 = infer_location(path)
    db.execute(
        """INSERT OR IGNORE INTO papers
        (title,file_path,category,venue,year,terms_json,search_text,size,is_upload,added_at)
        VALUES (?,?,?,?,?,?,?,?,?,datetime('now'))""",
        (title, relative, category or category0, venue or venue0, year or year0,
         json.dumps(make_terms(title, ""), ensure_ascii=False), title, path.stat().st_size, int(uploaded)),
    )


def initialize() -> None:
    with db_lock, connect_db() as db:
        db.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                username TEXT NOT NULL COLLATE NOCASE UNIQUE,
                role TEXT NOT NULL DEFAULT 'member' CHECK(role IN ('admin','member')),
                active INTEGER NOT NULL DEFAULT 1,
                password_hash TEXT,
                created_at TEXT NOT NULL DEFAULT (datetime('now'))
            );
            CREATE TABLE IF NOT EXISTS papers (
                id INTEGER PRIMARY KEY,
                title TEXT NOT NULL,
                file_path TEXT NOT NULL UNIQUE,
                category TEXT NOT NULL,
                venue TEXT NOT NULL,
                year TEXT NOT NULL,
                terms_json TEXT NOT NULL DEFAULT '[]',
                search_text TEXT NOT NULL DEFAULT '',
                text_indexed INTEGER NOT NULL DEFAULT 0,
                size INTEGER NOT NULL DEFAULT 0,
                is_upload INTEGER NOT NULL DEFAULT 0,
                added_at TEXT NOT NULL DEFAULT (datetime('now'))
            );
            CREATE INDEX IF NOT EXISTS papers_facets ON papers(category,venue,year);
        """)
        columns = {row[1] for row in db.execute("PRAGMA table_info(papers)")}
        if "text_indexed" not in columns:
            db.execute("ALTER TABLE papers ADD COLUMN text_indexed INTEGER NOT NULL DEFAULT 0")
        db.execute("PRAGMA journal_mode=WAL")
        initial_admin = os.environ.get("IICS_ADMIN_USERNAME", "admin").strip()
        if initial_admin:
            db.execute("INSERT OR IGNORE INTO users(username,role) VALUES (?, 'admin')", (initial_admin,))
        known = {row[0] for row in db.execute("SELECT file_path FROM papers")}
        for path in sorted(ROOT.rglob("*.pdf")):
            parts = path.relative_to(ROOT).parts
            if any(part in {"instance", "venv", ".venv"} for part in parts):
                continue
            if path.relative_to(ROOT).as_posix() not in known:
                insert_paper(db, path, uploaded=path.is_relative_to(UPLOAD_ROOT))

    start_text_indexer()


def index_worker(root: Path, db_path: Path) -> None:
    while True:
        paper_id, relative_path = index_queue.get()
        try:
            path = (root / relative_path).resolve()
            if not path.is_relative_to(root) or not path.is_file():
                text = ""
            else:
                text = read_pdf_text(path)
            with db_lock, connect_db(db_path) as db:
                paper = db.execute("SELECT title FROM papers WHERE id=?", (paper_id,)).fetchone()
                if paper:
                    db.execute("UPDATE papers SET terms_json=?,search_text=?,text_indexed=1 WHERE id=?",
                               (json.dumps(make_terms(paper["title"], text), ensure_ascii=False),
                                f"{paper['title']}\n{text}", paper_id))
        except Exception:
            with db_lock, connect_db(db_path) as db:
                db.execute("UPDATE papers SET text_indexed=1 WHERE id=?", (paper_id,))
        finally:
            index_queue.task_done()


def start_text_indexer() -> None:
    global indexer_started
    if not text_indexing_enabled:
        return
    with connect_db() as db:
        pending = db.execute("SELECT id,file_path FROM papers WHERE text_indexed=0 ORDER BY id").fetchall()
    for row in pending:
        index_queue.put((row["id"], row["file_path"]))
    if not indexer_started:
        thread = threading.Thread(target=index_worker, args=(ROOT, DB_PATH), name="iics-pdf-indexer", daemon=True)
        thread.start()
        indexer_started = True


def current_user():
    user_id = session.get("user_id")
    if not user_id:
        return None
    with connect_db() as db:
        user = db.execute("SELECT id,username,role,active FROM users WHERE id=?", (user_id,)).fetchone()
    if not user or not user["active"]:
        session.clear()
        return None
    return user


def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if current_user() is None:
            return jsonify(error="请先登录"), 401
        return fn(*args, **kwargs)
    return wrapped


def admin_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        user = current_user()
        if user is None:
            return jsonify(error="请先登录"), 401
        if user["role"] != "admin":
            return jsonify(error="无权执行此操作"), 403
        return fn(*args, **kwargs)
    return wrapped


@app.before_request
def protect_mutations():
    if request.method in {"POST", "PUT", "PATCH", "DELETE"} and session.get("user_id"):
        expected = session.get("csrf")
        supplied = request.headers.get("X-CSRF-Token", "")
        if not expected or not secrets.compare_digest(expected, supplied):
            return jsonify(error="请求已过期，请刷新页面"), 400


@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "same-origin"
    response.headers["Content-Security-Policy"] = "default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'"
    return response


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/session")
def session_state():
    user = current_user()
    if user is None:
        return jsonify(user=None)
    if not session.get("csrf"):
        session["csrf"] = secrets.token_urlsafe(24)
    return jsonify(user={"id": user["id"], "username": user["username"], "role": user["role"]}, csrf=session["csrf"])


@app.post("/api/auth/identify")
def identify():
    data = request.get_json(silent=True, force=True) or {}
    username = str(data.get("username", "")).strip()
    if not username or len(username) > 80:
        return jsonify(error="请输入有效用户名"), 400
    with connect_db() as db:
        user = db.execute("SELECT id,username,password_hash,active FROM users WHERE username=? COLLATE NOCASE", (username,)).fetchone()
    if not user or not user["active"]:
        return jsonify(error="此用户名未获授权"), 404
    return jsonify(username=user["username"], first_login=user["password_hash"] is None)


@app.post("/api/auth/password")
def authenticate():
    data = request.get_json(silent=True, force=True) or {}
    username = str(data.get("username", "")).strip()
    password = str(data.get("password", ""))
    if len(password) < 8 or len(password) > 200:
        return jsonify(error="密码长度需为 8–200 个字符"), 400
    with connect_db() as db:
        db.execute("BEGIN IMMEDIATE")
        user = db.execute("SELECT * FROM users WHERE username=? COLLATE NOCASE", (username,)).fetchone()
        if not user or not user["active"]:
            return jsonify(error="此用户名未获授权"), 404
        if user["password_hash"]:
            if not check_password_hash(user["password_hash"], password):
                return jsonify(error="密码不正确"), 401
        else:
            db.execute("UPDATE users SET password_hash=? WHERE id=? AND password_hash IS NULL",
                       (generate_password_hash(password), user["id"]))
        user_id = user["id"]
        actual = db.execute("SELECT username,role FROM users WHERE id=?", (user_id,)).fetchone()
    session.clear()
    session.permanent = True
    session["user_id"] = user_id
    session["csrf"] = secrets.token_urlsafe(24)
    return jsonify(user={"id": user_id, "username": actual["username"], "role": actual["role"]}, csrf=session["csrf"])


@app.post("/api/auth/logout")
@login_required
def logout():
    session.clear()
    return jsonify(ok=True)


@app.post("/api/auth/change-password")
@login_required
def change_password():
    data = request.get_json(silent=True, force=True) or {}
    old = str(data.get("current", ""))
    new = str(data.get("password", ""))
    if len(new) < 8 or len(new) > 200:
        return jsonify(error="新密码长度需为 8–200 个字符"), 400
    user_id = session["user_id"]
    with connect_db() as db:
        user = db.execute("SELECT password_hash FROM users WHERE id=?", (user_id,)).fetchone()
        if not user or not check_password_hash(user["password_hash"], old):
            return jsonify(error="当前密码不正确"), 401
        db.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new), user_id))
    return jsonify(ok=True)


@app.get("/api/papers")
@login_required
def papers():
    query = request.args.get("q", "").strip()[:200].lower()
    category = request.args.get("category", "").strip()
    venue = request.args.get("venue", "").strip()
    year = request.args.get("year", "").strip()
    term = request.args.get("term", "").strip()
    with connect_db() as db:
        rows = db.execute("SELECT * FROM papers ORDER BY year DESC, venue COLLATE NOCASE, title COLLATE NOCASE").fetchall()
    all_rows = [dict(row) for row in rows]
    categories = sorted({row["category"] for row in all_rows})
    venues = sorted({row["venue"] for row in all_rows})
    years = sorted({row["year"] for row in all_rows}, reverse=True)
    term_counts = Counter(term0 for row in all_rows for term0 in json.loads(row["terms_json"]))
    filtered = []
    for row in all_rows:
        terms = json.loads(row["terms_json"])
        if category and row["category"] != category:
            continue
        if venue and row["venue"] != venue:
            continue
        if year and row["year"] != year:
            continue
        if term and term not in terms:
            continue
        if query and query not in f"{row['title']} {row['search_text']} {row['venue']} {row['category']} {row['year']}".lower():
            continue
        filtered.append({"id": row["id"], "title": row["title"], "category": row["category"],
                         "venue": row["venue"], "year": row["year"], "terms": terms,
                         "size": row["size"], "is_upload": bool(row["is_upload"]), "added_at": row["added_at"]})
    return jsonify(papers=filtered, facets={"categories": categories, "venues": venues, "years": years,
                  "terms": [{"name": name, "count": count} for name, count in term_counts.most_common()]},
                   total=len(all_rows), matches=len(filtered))


@app.get("/api/papers/<int:paper_id>/download")
@login_required
def download(paper_id: int):
    with connect_db() as db:
        paper = db.execute("SELECT title,file_path FROM papers WHERE id=?", (paper_id,)).fetchone()
    if paper is None:
        abort(404)
    path = (ROOT / paper["file_path"]).resolve()
    if not path.is_relative_to(ROOT) or not path.is_file():
        abort(404)
    return send_file(path, as_attachment=True, download_name=path.name, mimetype="application/pdf")


@app.post("/api/papers")
@login_required
def upload_paper():
    file = request.files.get("file")
    if not file or not file.filename or Path(file.filename).suffix.lower() != ".pdf":
        return jsonify(error="请选择 PDF 文件"), 400
    original_name = Path(file.filename.replace("\\", "/")).name
    safe_name = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "_", original_name).strip(" ._")
    if not safe_name or safe_name == ".pdf":
        safe_name = f"paper-{uuid4().hex[:10]}.pdf"
    if not safe_name.lower().endswith(".pdf"):
        safe_name += ".pdf"
    data = file.stream.read(MAX_PDF_BYTES + 1)
    if len(data) > MAX_PDF_BYTES:
        return jsonify(error="单篇论文不能超过 100 MB"), 413
    if not data.startswith(b"%PDF-"):
        return jsonify(error="文件不是有效的 PDF"), 400
    category = request.form.get("category", "存内计算").strip()[:80] or "未分类"
    venue = request.form.get("venue", "其他").strip()[:80] or "其他"
    year = request.form.get("year", "未知").strip()[:12] or "未知"
    folder = UPLOAD_ROOT / secure_filename(category) / secure_filename(venue) / secure_filename(year)
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"{uuid4().hex[:8]}_{safe_name}"
    path.write_bytes(data)
    try:
        with db_lock, connect_db() as db:
            insert_paper(db, path, category=category, venue=venue, year=year, uploaded=True,
                         title=title_from_filename(safe_name))
            row = db.execute("SELECT id FROM papers WHERE file_path=?", (path.relative_to(ROOT).as_posix(),)).fetchone()
    except Exception:
        path.unlink(missing_ok=True)
        raise
    if text_indexing_enabled:
        index_queue.put((row["id"], path.relative_to(ROOT).as_posix()))
    return jsonify(ok=True, id=row["id"]), 201


@app.get("/api/users")
@admin_required
def users():
    with connect_db() as db:
        rows = db.execute("SELECT id,username,role,active,created_at,password_hash FROM users ORDER BY role DESC,username COLLATE NOCASE").fetchall()
    return jsonify(users=[{"id": row["id"], "username": row["username"], "role": row["role"],
                          "active": bool(row["active"]), "has_password": bool(row["password_hash"]),
                          "created_at": row["created_at"]} for row in rows])


@app.post("/api/users")
@admin_required
def add_user():
    data = request.get_json(silent=True, force=True) or {}
    username = str(data.get("username", "")).strip()
    if not username or len(username) > 80 or any(ord(char) < 32 for char in username):
        return jsonify(error="用户名需为 1–80 个字符"), 400
    role = "admin" if data.get("role") == "admin" else "member"
    try:
        with connect_db() as db:
            db.execute("INSERT INTO users(username,role) VALUES (?,?)", (username, role))
    except sqlite3.IntegrityError:
        return jsonify(error="此用户名已在白名单中"), 409
    return jsonify(ok=True), 201


@app.patch("/api/users/<int:user_id>")
@admin_required
def edit_user(user_id: int):
    data = request.get_json(silent=True, force=True) or {}
    with connect_db() as db:
        target = db.execute("SELECT id,role FROM users WHERE id=?", (user_id,)).fetchone()
        if not target:
            return jsonify(error="用户不存在"), 404
        if user_id == session["user_id"] and data.get("active") is False:
            return jsonify(error="不能停用当前账号"), 400
        role = data.get("role")
        if role in {"admin", "member"}:
            if target["role"] == "admin" and role == "member":
                admins = db.execute("SELECT count(*) FROM users WHERE role='admin' AND active=1").fetchone()[0]
                if admins <= 1:
                    return jsonify(error="至少保留一位启用的管理员"), 400
            db.execute("UPDATE users SET role=? WHERE id=?", (role, user_id))
        if isinstance(data.get("active"), bool):
            if not data["active"] and target["role"] == "admin":
                admins = db.execute("SELECT count(*) FROM users WHERE role='admin' AND active=1").fetchone()[0]
                if admins <= 1:
                    return jsonify(error="至少保留一位启用的管理员"), 400
            db.execute("UPDATE users SET active=? WHERE id=?", (int(data["active"]), user_id))
        if data.get("reset_password") is True:
            db.execute("UPDATE users SET password_hash=NULL WHERE id=?", (user_id,))
    return jsonify(ok=True)


@app.delete("/api/users/<int:user_id>")
@admin_required
def remove_user(user_id: int):
    if user_id == session["user_id"]:
        return jsonify(error="不能移除当前账号"), 400
    with connect_db() as db:
        target = db.execute("SELECT role FROM users WHERE id=?", (user_id,)).fetchone()
        if not target:
            return jsonify(error="用户不存在"), 404
        if target["role"] == "admin":
            admins = db.execute("SELECT count(*) FROM users WHERE role='admin' AND active=1").fetchone()[0]
            if admins <= 1:
                return jsonify(error="至少保留一位启用的管理员"), 400
        db.execute("DELETE FROM users WHERE id=?", (user_id,))
    return jsonify(ok=True)


@app.delete("/api/papers/<int:paper_id>")
@admin_required
def remove_paper(paper_id: int):
    with db_lock, connect_db() as db:
        paper = db.execute("SELECT file_path,is_upload FROM papers WHERE id=?", (paper_id,)).fetchone()
        if not paper:
            return jsonify(error="论文不存在"), 404
        if not paper["is_upload"]:
            return jsonify(error="原始论文目录中的文件需在文件夹中管理"), 400
        path = (ROOT / paper["file_path"]).resolve()
        if not path.is_relative_to(UPLOAD_ROOT.resolve()):
            return jsonify(error="文件路径无效"), 400
        db.execute("DELETE FROM papers WHERE id=?", (paper_id,))
        path.unlink(missing_ok=True)
    return jsonify(ok=True)


@app.errorhandler(413)
def too_large(_error):
    return jsonify(error="单篇论文不能超过 100 MB"), 413


initialize()


if __name__ == "__main__":
    host = os.environ.get("IICS_HOST", "127.0.0.1")
    port = int(os.environ.get("IICS_PORT", "8787"))
    print(f"IICS_lib running at http://{host}:{port}")
    from waitress import serve
    serve(app, host=host, port=port, threads=8)
